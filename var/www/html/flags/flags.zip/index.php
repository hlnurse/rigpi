<?php
//some php code
?>

<style type="text/css">
img.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
div.center {
  text-align: center;
}
</style>

<img src="../Images/RigPiW.png" width="100" height="100" alt="Pi" class="center" />
<p />
<div class="center"><H2>RigPi Station Server for Amateur Radio</H2></div>

